local ____lualib = require("lualib_bundle")
local __TS__ArrayIsArray = ____lualib.__TS__ArrayIsArray
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["6"] = 6,["7"] = 7,["8"] = 8,["9"] = 9,["10"] = 10,["11"] = 11,["12"] = 7,["13"] = 14,["14"] = 15,["15"] = 16,["16"] = 16,["18"] = 17,["19"] = 18,["20"] = 19,["21"] = 18,["22"] = 15,["23"] = 23,["24"] = 23,["25"] = 23,["26"] = 24,["27"] = 25,["28"] = 26,["29"] = 27,["31"] = 27,["34"] = 23,["35"] = 23});
local ____exports = {}
local lsId = "factorio-test.fake-translation"
local function fireFakeTranslation(data)
    local ls = {lsId, data}
    local player = game.connected_players[1]
    assert(player, "No connected players found to raise fake translation event. Please report this to the mod author")
    player.request_translation(ls)
end
local loadEvents = {}
function ____exports.postLoadAction(name, func)
    if loadEvents[name] ~= nil then
        error("duplicate load event name " .. name)
    end
    loadEvents[name] = func
    return function()
        fireFakeTranslation(name)
    end
end
script.on_event(
    defines.events.on_string_translated,
    function(data)
        local ls = data.localised_string
        if __TS__ArrayIsArray(ls) and ls[1] == lsId then
            local action = ls[2]
            local ____opt_0 = loadEvents[action]
            if ____opt_0 ~= nil then
                ____opt_0()
            end
        end
    end
)
return ____exports
