local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 2,["6"] = 3,["7"] = 4,["8"] = 5,["9"] = 6,["10"] = 9,["11"] = 9,["12"] = 9,["13"] = 9,["14"] = 11,["15"] = 12,["18"] = 13,["21"] = 15,["22"] = 16,["23"] = 18,["24"] = 18,["25"] = 18,["26"] = 19,["27"] = 21,["28"] = 22,["29"] = 22,["31"] = 23,["32"] = 24,["33"] = 25,["34"] = 26,["35"] = 27,["36"] = 28,["37"] = 21,["38"] = 31,["39"] = 32,["40"] = 33,["42"] = 35,["43"] = 36,["45"] = 39,["46"] = 40,["48"] = 43,["49"] = 44,["50"] = 18,["51"] = 18,["52"] = 11,["53"] = 49,["54"] = 50});
local ____exports = {}
local ____auto_2Dstart_2Dconfig = require("factorio-test.shared.auto-start-config")
local finishHeadlessTest = ____auto_2Dstart_2Dconfig.finishHeadlessTest
local getAutoStartMod = ____auto_2Dstart_2Dconfig.getAutoStartMod
local isAutoStartEnabled = ____auto_2Dstart_2Dconfig.isAutoStartEnabled
local isHeadlessMode = ____auto_2Dstart_2Dconfig.isHeadlessMode
local ____start_2Dtests = require("control.start-tests")
local hasAutoStarted = ____start_2Dtests.hasAutoStarted
local markAutoStarted = ____start_2Dtests.markAutoStarted
local startTests = ____start_2Dtests.startTests
local function armAutoStart()
    if not isAutoStartEnabled() then
        return
    end
    if hasAutoStarted() then
        return
    end
    local headless = isHeadlessMode()
    local modToTest = getAutoStartMod()
    script.on_event(
        defines.events.on_tick,
        function()
            script.on_event(defines.events.on_tick, nil)
            local function autoStartError(message)
                if not headless then
                    game.print(message)
                end
                log(message)
                print("FACTORIO-TEST-MESSAGE-START")
                log(message)
                print("FACTORIO-TEST-MESSAGE-END")
                print("FACTORIO-TEST-RESULT:" .. "could not auto start")
                finishHeadlessTest(false)
            end
            if modToTest == "level" then
                if not remote.interfaces["factorio-test-tests-available-for-" .. "level"] then
                    return autoStartError("Cannot auto-start tests: the scenario is not registered with Factorio Test.")
                end
            elseif not (script.active_mods[modToTest] ~= nil) then
                return autoStartError(("Cannot auto-start tests: mod " .. modToTest) .. " is not active.")
            end
            if not remote.interfaces["factorio-test"] then
                return autoStartError("Cannot auto-start tests: the selected mod is not registered with Factorio Test.")
            end
            markAutoStarted()
            startTests(modToTest)
        end
    )
end
script.on_load(armAutoStart)
script.on_init(armAutoStart)
return ____exports
