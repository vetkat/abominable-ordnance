local ____lualib = require("lualib_bundle")
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["7"] = 4,["8"] = 5,["9"] = 5,["10"] = 5,["12"] = 6,["13"] = 4,["14"] = 9,["15"] = 10,["16"] = 10,["18"] = 11,["19"] = 11,["20"] = 11,["21"] = 9,["22"] = 14,["23"] = 16,["24"] = 17,["25"] = 17,["26"] = 16,["27"] = 20,["28"] = 21,["29"] = 20,["30"] = 24,["31"] = 25,["32"] = 26,["33"] = 24,["34"] = 29,["35"] = 30,["36"] = 29,["37"] = 33,["38"] = 34,["39"] = 34,["41"] = 33});
local ____exports = {}
local function decodePayload(raw)
    local ____opt_0 = raw
    if not (____opt_0 and __TS__StringStartsWith(raw, "FACTORIO_TEST:")) then
        return {}
    end
    return helpers.json_to_table(__TS__StringSlice(raw, #"FACTORIO_TEST:"))
end
local function readPayload()
    if script.test_arg ~= nil then
        return decodePayload(script.test_arg)
    end
    local ____decodePayload_4 = decodePayload
    local ____opt_2 = settings.startup["factorio-test-auto-start-config"]
    return ____decodePayload_4(____opt_2 and ____opt_2.value)
end
local cachedPayload
function ____exports.getTestRunPayload()
    cachedPayload = cachedPayload or readPayload()
    return cachedPayload
end
function ____exports.isHeadlessMode()
    return script.test_arg ~= nil
end
function ____exports.isAutoStartEnabled()
    local mod = ____exports.getTestRunPayload().mod
    return mod ~= nil and mod ~= ""
end
function ____exports.getAutoStartMod()
    return ____exports.getTestRunPayload().mod
end
function ____exports.finishHeadlessTest(passed)
    if ____exports.isHeadlessMode() then
        script.finish_test(passed)
    end
end
return ____exports
